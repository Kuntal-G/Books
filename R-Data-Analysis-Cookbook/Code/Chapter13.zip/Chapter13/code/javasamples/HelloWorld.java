// This java code returns Hello World
package javasamples;
 
public class HelloWorld {
 
    public String getString() {
        return "Hello World";
    }
 
    public static void main(String[] args) {
 
    }
}
