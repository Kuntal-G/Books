
# Load auto-mpg.csv
auto=read.csv("auto-mpg.csv")
var1
var2
#Calculate correlation between the 2 columns
result = cor(auto[,var1],auto[,var2])
